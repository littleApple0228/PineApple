import sqlite3
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="PineApple Activity Platform API")

# 允許前端 CORS 跨域請求 (支援 Vite 前端)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_FILE = "pineapple.db"

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    # 建立 activities 資料表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            starts_at TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    # 建立 registrations 資料表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            activity_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (activity_id) REFERENCES activities(id)
        )
    ''')
    
    # 插入測試活動資料（若資料庫為空）
    cursor.execute("SELECT COUNT(*) FROM activities")
    if cursor.fetchone()[0] == 0:
        cursor.execute(
            "INSERT INTO activities (title, description, starts_at) VALUES (?, ?, ?)",
            ("迎新茶會野餐", "歡迎新同學加入！現場提供茶點與團康活動。", "2026-11-01 14:00:00")
        )
        cursor.execute(
            "INSERT INTO activities (title, description, starts_at) VALUES (?, ?, ?)",
            ("全校電競大賽", "英雄聯盟與跑跑卡丁車項目，歡迎組隊報名參加！", "2026-11-15 10:00:00")
        )
        conn.commit()
    conn.close()

@app.on_event("startup")
def startup_event():
    init_db()

# Request Body 驗證模型
class RegistrationCreate(BaseModel):
    activityId: int
    name: str
    phone: str

@app.get("/api/activities")
def get_activities():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, title, description, starts_at as startsAt, created_at as createdAt FROM activities")
    rows = cursor.fetchall()
    conn.close()
    activities = [dict(row) for row in rows]
    return {"data": activities}

@app.post("/api/registrations", status_code=201)
def create_registration(data: RegistrationCreate):
    if not data.name.strip() or not data.phone.strip():
        raise HTTPException(status_code=400, detail="請填寫完整姓名與電話")
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 檢查活動是否存在
    cursor.execute("SELECT id FROM activities WHERE id = ?", (data.activityId,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="找不到該活動")

    cursor.execute(
        "INSERT INTO registrations (activity_id, name, phone) VALUES (?, ?, ?)",
        (data.activityId, data.name, data.phone)
    )
    reg_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return {
        "data": {
            "id": reg_id,
            "activityId": data.activityId,
            "name": data.name,
            "phone": data.phone
        }
    }
